# Computer-Graphics
This is the offical repository for the computer graphics mini project. 


1. Print name on the screen. bottom right. 
2. Make the bob ossilate across the screen, boucing across the edges.
3. It acclerates when it touches the left and right edge
