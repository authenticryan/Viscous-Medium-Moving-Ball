gcc water.cpp gl_helper.cpp -o ripple -lGLU -lGL -lglut
./ripple
